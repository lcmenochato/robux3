import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import logo from "@/assets/logo.png.asset.json";

export type Pack = { qty: number; price: number; old: number };
export const packs: Pack[] = [
  [400, 7.9, 9.9], [800, 13.9, 16.9], [1200, 19.9, 24], [1700, 24.9, 26],
  [2500, 36.9, 44.9], [3600, 49.9, 59.9], [4500, 62.9, 74.9], [10000, 129.9, 159.9],
].map(([qty, price, old]) => ({ qty: qty!, price: price!, old: old! }));
export const findPack = (q: string) => packs.find((p) => String(p.qty) === q);
export const brl = (n: number) => "R$ " + n.toFixed(2).replace(".", ",");
export const fmt = (n: number) => n.toLocaleString("pt-BR");
export const off = (p: Pack) => Math.round((1 - p.price / p.old) * 100);
export { logo };

export function Coin({ className = "" }: { className?: string }) {
  return (
    <div className={`grid place-items-center rounded-2xl bg-silver ${className}`}>
      <div className="h-1/3 w-1/3 rotate-12 rounded-sm border-4 border-primary-foreground/70" />
    </div>
  );
}

export function PackArt({ p, big = false }: { p: Pack; big?: boolean }) {
  return (
    <div className={`flex flex-col items-center justify-center gap-2 rounded-2xl border border-border bg-muted ${big ? "aspect-[3/4] gap-4" : "py-5"}`}>
      <p className={`font-display text-silver ${big ? "text-3xl" : "text-sm"}`}>KINGDOM</p>
      <Coin className={big ? "h-28 w-28 rounded-3xl" : "h-12 w-12"} />
      <p className={`text-center font-display leading-none text-silver ${big ? "text-6xl" : "text-2xl"}`}>{fmt(p.qty)}<br />ROBUX</p>
    </div>
  );
}

export function Header({ secure = false }: { secure?: boolean }) {
  const [menu, setMenu] = useState(false);
  return (
    <>
      <div className="h-1 bg-silver" />
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/90 px-4 py-2 backdrop-blur">
        <Link to="/"><img src={logo.url} alt="Kingdom Robux" className="h-11 w-11" /></Link>
        {secure ? (
          <span className="text-xs text-muted-foreground">🔒 Checkout seguro</span>
        ) : (
          <button onClick={() => setMenu(!menu)} aria-label="Menu" className="grid h-10 w-10 place-items-center rounded-lg border border-border">☰</button>
        )}
        {menu && (
          <nav className="absolute right-4 top-16 flex flex-col gap-3 rounded-xl border border-border bg-card p-4 text-sm">
            <Link to="/" onClick={() => setMenu(false)}>Início</Link>
            <a href="/#pacotes" onClick={() => setMenu(false)}>Pacotes</a>
            <a href="/#faq" onClick={() => setMenu(false)}>Perguntas</a>
          </nav>
        )}
      </header>
    </>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-border px-4 pb-28 pt-8 text-sm">
      <img src={logo.url} alt="" className="h-12 w-12" />
      <p className="mt-4 text-xs leading-relaxed text-muted-foreground">Kingdom Robux entrega Robux com PIX ou cartão, checkout protegido e entrega automática após a confirmação do pagamento.</p>
      <div className="mt-4 flex items-center gap-3"><span className="font-display text-3xl italic text-silver">Reclame AQUI</span><span className="text-[10px] leading-tight text-muted-foreground">Loja avaliada<br />no Reclame AQUI</span></div>
      <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground"><p className="text-sm font-semibold text-foreground">Loja</p><a href="/#pacotes">Pacotes de Robux</a><a href="#">Abrir ticket</a><a href="#">Minha conta</a><a href="/#como">Como funciona</a></div>
      <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground"><p className="text-sm font-semibold text-foreground">Legal</p><a href="#">Privacidade</a><a href="#">Termos de uso</a></div>
      <div className="mt-8 border-t border-border pt-6 text-center">
        <p className="text-[11px] font-semibold tracking-[0.2em] text-muted-foreground">COMPRA 100% SEGURA</p>
        <div className="mt-3 flex justify-center gap-2 text-[11px] font-extrabold">
          {["🛡 Google Site Seguro", "🔒 SSL Blindado", "✔ Site Blindado"].map((t) => <span key={t} className="rounded-md border border-border px-2 py-1">{t}</span>)}
        </div>
        <p className="mt-4 text-[10px] text-muted-foreground">© 2021-2026 Kingdom Robux. Todos os direitos reservados.</p>
      </div>
    </footer>
  );
}

const buyers: [string, number][] = [["Gustavo", 3600], ["Rafael", 1700], ["Beatriz", 3600], ["Lucas", 10000], ["Ana", 1200]];
export function BuyerToast() {
  const [b, setB] = useState(0);
  useEffect(() => { const t = setInterval(() => setB((x) => (x + 1) % buyers.length), 6000); return () => clearInterval(t); }, []);
  const [n, q] = buyers[b]!;
  return (
    <div key={b} className="fixed bottom-4 left-4 right-4 z-40 mx-auto flex max-w-sm items-center gap-3 rounded-2xl border border-border bg-card p-3 animate-toast">
      <Coin className="h-10 w-10" />
      <div className="text-sm">
        <p className="text-xs font-extrabold tracking-widest text-primary">ACABOU DE COMPRAR</p>
        <p className="font-semibold">{n} · {fmt(q)} Robux</p>
        <p className="text-xs text-muted-foreground">entrega automática liberada</p>
      </div>
    </div>
  );
}

export function VideoBox({ title }: { title: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 text-center">
      <p className="font-display text-lg tracking-wide text-silver">{title}</p>
      <div className="relative mt-3 grid aspect-[9/14] place-items-center overflow-hidden rounded-xl bg-muted">
        <img src={logo.url} alt="" className="absolute w-2/3 opacity-20" />
        <button aria-label="Assistir" className="relative grid h-16 w-16 place-items-center rounded-full bg-silver text-2xl text-primary-foreground">▶</button>
      </div>
    </div>
  );
}
