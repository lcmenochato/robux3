import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import logo from "@/assets/logo.png.asset.json";
import banner from "@/assets/banner.png.asset.json";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Kingdom Robux | Robux barato e entrega automática" },
      { name: "description", content: "Compre Robux barato com PIX e receba na hora. Kingdom Robux, a loja de Robux do reino." },
      { property: "og:title", content: "Kingdom Robux | Robux barato" },
      { property: "og:description", content: "Robux com PIX e entrega automática." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const packs: [number, number, number][] = [
  [400, 7.9, 9.9], [800, 13.9, 16.9], [1200, 19.9, 24], [1700, 24.9, 26],
  [2500, 36.9, 44.9], [3600, 49.9, 59.9], [4500, 62.9, 74.9], [10000, 129.9, 159.9],
];
const brl = (n: number) => "R$ " + n.toFixed(2).replace(".", ",");
const faqs = [
  ["Onde comprar Robux barato e seguro?", "Aqui na Kingdom Robux, com preços abaixo da loja oficial e checkout protegido."],
  ["Como recebo os Robux depois de pagar?", "Após a confirmação do pagamento, a entrega é feita automaticamente na sua conta."],
  ["Qual é o tempo de processamento dos pedidos?", "Normalmente poucos minutos após a confirmação do PIX."],
  ["Preciso informar a senha do Roblox?", "Não. Pedimos apenas o nome de usuário."],
  ["Quais formas de pagamento são aceitas?", "PIX e cartão de crédito."],
  ["Preciso criar uma conta no site para comprar?", "Não é obrigatório, mas facilita acompanhar seus pedidos."],
  ["Posso cancelar minha compra após o pagamento?", "Se a entrega ainda não foi feita, abra um ticket que analisamos o reembolso."],
  ["Como acessar o suporte?", "Pelo botão Abrir ticket no rodapé ou pelo nosso Instagram."],
];
const buyers: [string, number][] = [["Gustavo", 3600], ["Rafael", 1700], ["Ana", 800], ["Lucas", 10000], ["Bia", 1200]];

function Coin({ className = "" }: { className?: string }) {
  return (
    <div className={`grid place-items-center rounded-2xl bg-silver ${className}`}>
      <div className="h-1/3 w-1/3 rotate-12 rounded-sm border-4 border-primary-foreground/70" />
    </div>
  );
}

const H2 = ({ children }: { children: ReactNode }) => (
  <h2 className="font-display text-2xl tracking-wide text-silver">{children}</h2>
);

function Index() {
  const [open, setOpen] = useState<number | null>(null);
  const [menu, setMenu] = useState(false);
  const [b, setB] = useState(0);
  useEffect(() => { const t = setInterval(() => setB((x) => (x + 1) % buyers.length), 6000); return () => clearInterval(t); }, []);

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <div className="h-1 bg-silver" />
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border bg-background/90 px-4 py-2 backdrop-blur">
        <img src={logo.url} alt="Kingdom Robux" className="h-11 w-11" />
        <button onClick={() => setMenu(!menu)} aria-label="Menu" className="grid h-10 w-10 place-items-center rounded-lg border border-border">☰</button>
        {menu && (
          <nav className="absolute right-4 top-16 flex flex-col gap-3 rounded-xl border border-border bg-card p-4 text-sm">
            {[["Promoções", "#pacotes"], ["Como funciona", "#como"], ["Perguntas", "#faq"]].map(([l, h]) => (
              <a key={h} href={h} onClick={() => setMenu(false)}>{l}</a>
            ))}
          </nav>
        )}
      </header>

      <img src={banner.url} alt="Kingdom Robux" className="w-full" />

      <section id="pacotes" className="py-8">
        <div className="mb-4 flex items-end justify-between px-4">
          <div><H2>PROMOÇÕES</H2><div className="mt-1 h-0.5 w-16 bg-silver" /></div>
          <a href="#pacotes" className="text-xs text-muted-foreground">Ver todos</a>
        </div>
        <div className="flex snap-x gap-3 overflow-x-auto px-4 pb-2">
          {packs.map(([q, p, old], i) => (
            <div key={q} className="w-[44%] min-w-[160px] shrink-0 snap-start overflow-hidden rounded-2xl border border-border bg-card md:w-56">
              <div className="relative flex flex-col items-center gap-1 bg-muted py-5">
                {i === 2 && <span className="absolute left-2 top-2 rounded-md bg-background px-2 py-0.5 text-[10px] font-semibold">Mais pedido</span>}
                <span className="absolute right-2 top-2 text-[10px] font-extrabold text-primary">-{Math.round((1 - p / old) * 100)}%</span>
                <p className="font-display text-sm text-silver">KINGDOM</p>
                <Coin className="h-12 w-12" />
                <p className="text-center font-display text-2xl leading-none text-silver">{q.toLocaleString("pt-BR")}<br />ROBUX</p>
              </div>
              <div className="p-3">
                <p className="text-sm font-extrabold">{q.toLocaleString("pt-BR")} ROBUX</p>
                <p className="text-[10px] text-muted-foreground">121 vendidos</p>
                <div className="mt-2 flex items-center justify-between gap-1">
                  <div className="flex items-baseline gap-1">
                    <span className="font-extrabold text-primary">{brl(p)}</span>
                    <span className="text-[9px] text-muted-foreground line-through">{brl(old)}</span>
                  </div>
                  <Link to="/produto/$qtd" params={{ qtd: String(q) }} className="rounded-md bg-silver px-2 py-1 text-xs font-extrabold text-primary-foreground">Comprar</Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section id="como" className="px-4 pb-10 text-center">
        <H2>COMO FUNCIONA A COMPRA?</H2>
        <div className="mx-auto my-2 h-0.5 w-24 bg-silver" />
        <p className="text-xs text-muted-foreground">Processo simples e rápido!</p>
        <div className="relative mt-5 grid aspect-[9/12] place-items-center overflow-hidden rounded-2xl border border-border bg-card">
          <img src={logo.url} alt="" className="absolute w-2/3 opacity-20" />
          <button aria-label="Assistir" className="relative grid h-16 w-16 place-items-center rounded-full bg-silver text-2xl text-primary-foreground">▶</button>
          <div className="absolute inset-x-3 bottom-3 flex items-center gap-3 text-xs text-muted-foreground"><span>▶</span><span>🔊</span><span>00:00 / 03:51</span></div>
        </div>
      </section>

      <section className="px-4 pb-10 text-center">
        <H2>MAIS DE 100 MIL SEGUIDORES!</H2>
        <p className="mx-auto mt-2 max-w-xs text-xs text-muted-foreground">Junte-se à nossa comunidade e fique por dentro das melhores ofertas.</p>
        <div className="mt-5 rounded-3xl bg-foreground p-4 text-left text-background">
          <div className="flex items-center justify-between font-extrabold"><span>‹ kingdomrobuxoficial ✔</span><span>🔔 ⋯</span></div>
          <div className="mt-3 flex items-center gap-4">
            <img src={logo.url} alt="" className="h-20 w-20 rounded-full border border-border bg-background" />
            <div>
              <p className="text-sm font-extrabold">Kingdom Robux | Robux Barato | Loja Oficial</p>
              <div className="mt-2 flex gap-4 text-sm"><span><b>14</b> posts</span><span><b>129 mil</b> seguidores</span><span><b>1</b> seguindo</span></div>
            </div>
          </div>
          <p className="mt-3 text-sm opacity-60">Gamer</p>
          <p className="text-sm">👑 Maior reino de Robux do Brasil<br />🔥 Pagar caro em Robux? Aqui não!<br />🛒 Compre no nosso site e receba na hora!</p>
        </div>
      </section>

      <section className="px-4 pb-10 text-center">
        <H2>EXPLORE O MUNDO ROBLOX</H2>
        <p className="mt-2 text-xs text-muted-foreground">Milhares de jogos e experiências esperam por você.</p>
        <img src={banner.url} alt="" className="mt-5 aspect-video w-full rounded-2xl object-cover" />
      </section>

      <section className="px-4 pb-10 text-center">
        <H2>ENTREGA AUTOMÁTICA</H2>
        <p className="mt-2 text-xs text-muted-foreground">Receba seus Robux instantaneamente após a confirmação do pagamento via PIX.</p>
        <div className="mt-5 rounded-full bg-silver animate-shine py-2.5 text-left pl-5 font-display text-2xl italic tracking-wide text-primary-foreground">ENTREGA AUTOMÁTICA</div>
      </section>

      <section id="faq" className="px-4 pb-10">
        <h2 className="mb-4 font-display text-2xl text-silver">PERGUNTAS FREQUENTES</h2>
        <div className="divide-y divide-border rounded-2xl border border-border bg-card px-2">
          {faqs.map(([q, a], i) => (
            <button key={q} onClick={() => setOpen(open === i ? null : i)} className="block w-full p-3 text-left text-sm">
              <p className="font-semibold">{q}</p>
              {open === i && <p className="mt-2 text-muted-foreground">{a}</p>}
            </button>
          ))}
        </div>
      </section>

      <footer className="border-t border-border px-4 pb-28 pt-8 text-sm">
        <img src={logo.url} alt="" className="h-12 w-12" />
        <p className="mt-4 text-xs leading-relaxed text-muted-foreground">Kingdom Robux entrega Robux com PIX ou cartão, checkout protegido e entrega automática após a confirmação do pagamento.</p>
        <div className="mt-4 flex items-center gap-3"><span className="font-display text-3xl italic text-silver">Reclame AQUI</span><span className="text-[10px] leading-tight text-muted-foreground">Loja avaliada<br />no Reclame AQUI</span></div>
        <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground"><p className="text-sm font-semibold text-foreground">Loja</p><a href="#pacotes">Pacotes de Robux</a><a href="#">Abrir ticket</a><a href="#">Minha conta</a><a href="#como">Como funciona</a></div>
        <div className="mt-6 flex flex-col gap-2 text-xs text-muted-foreground"><p className="text-sm font-semibold text-foreground">Legal</p><a href="#">Privacidade</a><a href="#">Termos de uso</a></div>
        <div className="mt-8 border-t border-border pt-6 text-center">
          <p className="text-[11px] font-semibold tracking-[0.2em] text-muted-foreground">COMPRA 100% SEGURA</p>
          <div className="mt-3 flex justify-center gap-2 text-[11px] font-extrabold">
            {["🛡 Google Site Seguro", "🔒 SSL Blindado", "✔ Site Blindado"].map((t) => <span key={t} className="rounded-md border border-border px-2 py-1">{t}</span>)}
          </div>
          <p className="mt-4 text-[10px] text-muted-foreground">© 2021-2026 Kingdom Robux. Todos os direitos reservados.</p>
        </div>
      </footer>

      <div key={b} className="fixed bottom-4 left-4 right-4 z-40 mx-auto flex max-w-sm items-center gap-3 rounded-2xl border border-border bg-card p-3 animate-toast">
        <Coin className="h-10 w-10" />
        <div className="text-sm">
          <p className="text-xs font-extrabold tracking-widest text-primary">ACABOU DE COMPRAR</p>
          <p className="font-semibold">{buyers[b]![0]} · {buyers[b]![1].toLocaleString("pt-BR")} Robux</p>
          <p className="text-xs text-muted-foreground">entrega automática liberada</p>
        </div>
      </div>
    </div>
  );
}
