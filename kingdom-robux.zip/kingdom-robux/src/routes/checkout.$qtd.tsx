import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { Header, PackArt, brl, findPack, fmt } from "@/components/shop";

export const Route = createFileRoute("/checkout/$qtd")({
  loader: ({ params }) => {
    const p = findPack(params.qtd);
    if (!p) throw notFound();
    return p;
  },
  head: () => ({
    meta: [
      { title: "Checkout | Kingdom Robux" },
      { name: "description", content: "Finalize sua compra de Robux com PIX." },
      { property: "og:title", content: "Checkout | Kingdom Robux" },
      { property: "og:description", content: "Pague no PIX e receba seus Robux na hora." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: Checkout,
});

const reviews = [
  ["Meu pedido chegou em minutos, o melhor de todos", "Pedro", "há 5 dias"],
  ["Gostei 😃", "Enzo", "há 1 semana"],
  ["Super confiável, já comprei 3 vezes", "Julia", "há 2 semanas"],
];

function Checkout() {
  const p = Route.useLoaderData();
  const [step, setStep] = useState(2);
  const [nick, setNick] = useState("");
  const [email, setEmail] = useState("");
  const [nome, setNome] = useState("");
  const [ok, setOk] = useState(false);
  const valid = nick.trim().length > 2 && /\S+@\S+\.\S+/.test(email) && ok;
  const input = "mt-2 w-full rounded-xl border border-border bg-background px-3 py-3 text-sm outline-none focus:border-primary";

  return (
    <div className="min-h-screen bg-background pb-12 font-sans text-foreground">
      <Header secure />
      <main className="mx-auto max-w-md px-4 py-5">
        <div className="mb-5 flex items-center justify-between text-xs">
          {["Pacote", "Seus dados", "Pagamento"].map((s, i) => (
            <div key={s} className="flex items-center gap-2">
              <span className={`grid h-7 w-7 place-items-center rounded-full border text-[11px] font-bold ${i + 1 < step ? "bg-silver text-primary-foreground border-transparent" : i + 1 === step ? "border-primary" : "border-border text-muted-foreground"}`}>{i + 1 < step ? "✓" : i + 1}</span>
              <span className={i + 1 === step ? "font-semibold" : "text-muted-foreground"}>{s}</span>
            </div>
          ))}
        </div>

        <div className="rounded-3xl border border-border bg-card p-5">
          <p className="text-[11px] font-semibold tracking-[0.2em] text-muted-foreground">CHECKOUT KINGDOM ROBUX</p>
          {step === 2 ? (
            <>
              <h1 className="mt-2 text-2xl font-semibold">Seus dados</h1>
              <p className="mt-1 text-sm text-muted-foreground">Informe a conta, pague no PIX e receba na hora após a confirmação.</p>
              <label className="mt-5 block text-sm font-semibold">Conta do Roblox<input className={input} placeholder="seuNick" value={nick} onChange={(e) => setNick(e.target.value)} /></label>
              <p className="mt-1 text-[11px] text-muted-foreground">A entrega vai para esta conta. Confira o nick com atenção.</p>
              <label className="mt-4 block text-sm font-semibold">E-mail<input className={input} type="email" placeholder="voce@email.com" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
              <p className="mt-1 text-[11px] text-muted-foreground">Enviamos o comprovante e o código do pedido aqui.</p>
              <label className="mt-4 block text-sm font-semibold">Nome <span className="font-normal text-muted-foreground">(opcional)</span><input className={input} placeholder="Como podemos te chamar" value={nome} onChange={(e) => setNome(e.target.value)} /></label>
              <p className="mt-5 text-sm font-semibold">Forma de pagamento</p>
              <div className="mt-2 flex items-center gap-3 rounded-xl border border-primary bg-muted p-3">
                <span className="text-2xl">💠</span>
                <div><p className="text-sm font-semibold">Pagamento instantâneo via PIX</p><p className="text-[11px] text-muted-foreground">Aprovação imediata · QR Code e Copia e Cola</p></div>
              </div>
              <label className="mt-5 flex items-start gap-2 text-xs text-muted-foreground">
                <input type="checkbox" checked={ok} onChange={(e) => setOk(e.target.checked)} className="mt-0.5" />
                <span>Li e aceito os <u className="text-foreground">termos</u> e a <u className="text-foreground">política de privacidade</u>.</span>
              </label>
              <button disabled={!valid} onClick={() => setStep(3)} className="mt-4 w-full rounded-xl bg-silver py-3 text-sm font-extrabold text-primary-foreground disabled:opacity-40">Pagar com PIX agora</button>
              <p className="mt-3 text-center text-[11px] text-muted-foreground">Após o pagamento, a entrega automática começa na hora.</p>
            </>
          ) : (
            <div className="text-center">
              <h1 className="mt-2 text-2xl font-semibold">Pagamento PIX</h1>
              <p className="mt-1 text-sm text-muted-foreground">Entrega para <b className="text-foreground">{nick}</b></p>
              <div className="mx-auto mt-5 grid aspect-square w-48 place-items-center rounded-2xl bg-foreground text-xs text-background">QR Code PIX</div>
              <p className="mt-4 text-2xl font-extrabold text-primary">{brl(p.price)}</p>
              <p className="mt-4 rounded-xl border border-dashed border-border p-3 text-sm text-muted-foreground">O pagamento PIX ainda está sendo configurado pela loja. Em breve você poderá pagar por aqui.</p>
              <button onClick={() => setStep(2)} className="mt-4 text-xs underline text-muted-foreground">Voltar e editar dados</button>
            </div>
          )}
        </div>

        <div className="mt-5 flex items-center gap-4 rounded-3xl border border-border bg-card p-4">
          <div className="w-20 shrink-0"><PackArt p={p} /></div>
          <div>
            <p className="text-sm font-semibold">{fmt(p.qty)} Robux</p>
            <p><span className="font-extrabold text-primary">{brl(p.price)}</span> <span className="text-xs text-muted-foreground line-through">{brl(p.old)}</span></p>
            <p className="text-[11px] text-muted-foreground">121 pessoas já compraram este pacote</p>
          </div>
        </div>
        <Link to="/produto/$qtd" params={{ qtd: String(p.qty) }} className="mt-3 block text-center text-xs text-muted-foreground underline">Voltar ao pacote</Link>

        <p className="mt-10 text-[11px] font-semibold tracking-[0.2em] text-muted-foreground">QUEM JÁ COMPROU</p>
        <h2 className="text-xl font-semibold">O que os clientes dizem</h2>
        <span className="mt-2 inline-block rounded-full border border-border px-3 py-1 text-xs"><span className="text-primary">★★★★★</span> <b>4,9</b> · 18 feedbacks</span>
        <div className="-mx-4 mt-4 flex snap-x gap-3 overflow-x-auto px-4">
          {reviews.map(([t, n, d]) => (
            <div key={n} className="w-64 shrink-0 snap-start rounded-2xl border border-border bg-card p-4">
              <div className="flex justify-between text-xs"><span className="text-primary">★★★★★</span><span className="text-muted-foreground">{d}</span></div>
              <p className="mt-2 text-sm">“{t}”</p>
              <div className="mt-3 flex items-center gap-2 text-xs"><span className="grid h-7 w-7 place-items-center rounded-full bg-muted">{n?.[0]}</span><div><p className="font-semibold">{n}</p><p className="text-muted-foreground">✓ Comprou {fmt(p.qty)} Robux</p></div></div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
