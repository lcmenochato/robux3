import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { BuyerToast, Footer, Header, PackArt, VideoBox, brl, findPack, fmt, off } from "@/components/shop";

export const Route = createFileRoute("/produto/$qtd")({
  loader: ({ params }) => {
    const p = findPack(params.qtd);
    if (!p) throw notFound();
    return p;
  },
  head: ({ loaderData: p }) => ({
    meta: p
      ? [
          { title: `${fmt(p.qty)} Robux por ${brl(p.price)} | Kingdom Robux` },
          { name: "description", content: `Compre ${fmt(p.qty)} Robux com PIX e entrega automática.` },
          { property: "og:title", content: `${fmt(p.qty)} Robux | Kingdom Robux` },
          { property: "og:description", content: `${fmt(p.qty)} Robux por ${brl(p.price)} com entrega automática.` },
          { property: "og:type", content: "product" },
          { name: "twitter:card", content: "summary_large_image" },
        ]
      : [{ title: "Pacote não encontrado | Kingdom Robux" }, { name: "robots", content: "noindex" }],
  }),
  component: Produto,
});

function Produto() {
  const p = Route.useLoaderData();
  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <Header />
      <a href="/#pacotes" className="block border-b border-border py-3 text-center text-xs font-semibold tracking-widest">▦ TODOS OS PRODUTOS</a>
      <main className="mx-auto max-w-md px-4 py-5">
        <PackArt p={p} big />
        <p className="mt-4 text-xs text-muted-foreground"><b className="text-foreground">121</b> vendidos</p>
        <h1 className="text-2xl font-extrabold">{fmt(p.qty)} ROBUX</h1>
        <div className="mt-2 inline-block -skew-x-12 rounded-md bg-silver animate-shine px-3 py-1 font-display text-lg text-primary-foreground">ENTREGA AUTOMÁTICA</div>
        <div className="mt-3 flex items-center gap-2">
          <span className="text-2xl font-extrabold text-primary">{brl(p.price)}</span>
          <span className="text-xs text-muted-foreground line-through">{brl(p.old)}</span>
          <span className="rounded bg-muted px-1.5 text-[10px] font-bold">-{off(p)}%</span>
        </div>
        <p className="text-[11px] text-muted-foreground">No PIX ou cartão, com entrega automática após a confirmação.</p>
        <Link to="/checkout/$qtd" params={{ qtd: String(p.qty) }} className="mt-4 block rounded-xl bg-silver py-3 text-center text-sm font-extrabold text-primary-foreground">COMPRAR AGORA</Link>
        <a href="/#pacotes" className="mt-3 block rounded-xl border border-border py-3 text-center text-sm font-extrabold">VER OUTROS PACOTES</a>
        <div className="mt-8"><VideoBox title="COMO RESGATAR SEUS ROBUX" /></div>
      </main>
      <Footer />
      <BuyerToast />
    </div>
  );
}
